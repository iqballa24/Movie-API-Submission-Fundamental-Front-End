class NavBar extends HTMLElement {
    constructor() {
        super();
        this.shadowDOM = this.attachShadow({ mode: "open" });
    }
    connectedCallback() {
        this.render();
    }

    render() {
        this.shadowDOM.innerHTML = `
        <style>
            *{
                margin: 0;
                padding: 5px;
                box-sizing: border-box;
            }
            :host {
                display: block;
                width: 100%;
                background-color: #0c3454;
                font-size: inherit ;
                color: white;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            }
            h3{
                display: inline;
            }
            p{
                display: inline;
            }
            nav{
                padding: 10px;
                position: sticky;
	            top: 0;
            }
            nav li{
                display: inline;
            }
            nav a{
                text-decoration: none;
                font-size: inherit;
                color: white;
            }
            @media screen and (max-width: 453px){
                :host{
                    font-size: 70%;
                }
            }
        </style>
         
        <nav>
            <ul>
                <li><h3>Gudang Film</h3></li>
                <li><a href="#popular">Popular</a></li>
                <li><a href="#nowPlaying">Now playing</a></li>
                <li><a href="#upcoming">Upcoming</a></li>
            </ul>
        </nav>
        `;
        

    }
}

customElements.define("nav-bar", NavBar);