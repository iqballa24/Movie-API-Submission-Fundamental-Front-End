const baseUrl = "https://api.themoviedb.org/3/movie/upcoming?api_key=3972fe62c1fecb0fec5a00350c83f10b&language=en-US&region=id";
    const getMovie = () => {
        fetch(`${baseUrl}`)
            .then(response => {
                return response.json();
            })
            .then(responseJson => {
                if (responseJson.error) {
                    showResponseMessage(responseJson.message);
                } else {
                    renderAllMovies(responseJson.results);
                }
            })
            .catch(error => {
                showResponseMessage(error);
            })
    };
    const renderAllMovies = (movies) => {
        const listMovieElement = document.querySelector("#listUpComing");
        listMovieElement.innerHTML = "";

        movies.forEach(movie => {
            listMovieElement.innerHTML += `
                <style>
                    #listUpComing{
                        display: flex;
                        flex-wrap: wrap;
                        margin: 18px 8px;
                        overflow-y: scroll;
                        justify-content: center;
                        width: auto;
                        max-height: 470px;
                    @media screen and (max-width:600px){
                        #listUpComing{
                        justify-content: center;    
                        }     
                    }
                </style>
                <div class="card-box">
                    <img class="fan-art-movie" src="https://image.tmdb.org/t/p/w500/`+ movie.poster_path + `" alt="Fan Art">
                    <div class="content">
                        <h4>${movie.original_title}</h4>
                        <p>Release date : ${movie.release_date}</p>
                        <p>Plot : ${movie.overview}</p>
                    </div>
                </div>`;
        });
    };

    const showResponseMessage = (message = "Check your internet connection") => {
        alert(message);
    };
    document.addEventListener("DOMContentLoaded", () => {
        getMovie();
    });
