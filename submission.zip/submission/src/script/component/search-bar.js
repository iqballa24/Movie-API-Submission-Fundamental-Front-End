class SearchBar extends HTMLElement {
    constructor(){
        super();
        this.shadowDOM = this.attachShadow({mode: "open"});
    }
    connectedCallback() {
        this.render();
    }
    
    set clickEvent(event) {
        this._clickEvent = event;
        this.render();
    }

    get value() {
        return this.shadowDOM.querySelector("#searchElement").value;
    }

    render() {
        this.shadowDOM.innerHTML = `
        <style>
        .search-container {
                max-width: 800px;
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
                padding: 3px;
                border-radius: 28px;
                display: flex;
                position: sticky;
                top: 10px;
                background-color: white;
                margin: 10px auto;
                display: block;
                
            }
            .search-container:hover{
                border: 3px double #0c3454;
            }

            .search-container > input {
                width: 80%;
                padding: inherit;
                font-size: inherit;
                text-align: center;
                border: 0;
            }

            .search-container > input:focus::placeholder {
                font-weight: bold;
            }

            .search-container >  input::placeholder {
                color: #0c3454;
                font-weight: normal;
            }

            .search-container > button {
                width: 18%;
                cursor: pointer;
                margin-left: auto;
                padding: 16px;
                background-color: #0c3454;
                color: white;
                border: 0;
                text-transform: uppercase;
                border-radius: inherit;
            }

            .search-container > button:hover {
                background-color: #8193f5;
            }
            h1{
                font: xx-large;
                font-family: 'Source Sans Pro', sans-serif ;
                color: #0c3454;
                text-align: center;
                margin: 5px;
            }
            @media screen and (max-width: 550px){
                .search-container {
                    flex-direction: column;
                    position: static;
                    margin: 20px;
                    border-radius: 10px;
                }

                .search-container > input {
                    width: 100%;
                    margin-bottom: 12px;
                }

                .search-container > button {
                    width: 100%;
                }
            }
        </style>
        <h1>Cari film</h1>
        <div id="search-container" class="search-container">
            <input placeholder="Ketik judul filmnya gan.." id="searchElement" type="search">
            <button id="searchButtonElement" type="submit">Search</button>
        </div>`;

        this.shadowDOM.querySelector("#searchButtonElement").addEventListener("click", this._clickEvent);
        
    }
}

customElements.define("search-bar", SearchBar);