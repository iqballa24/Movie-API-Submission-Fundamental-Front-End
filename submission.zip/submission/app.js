import "./src/styles/style.css";
import "./src/script/component/popular-list.js";
import "./src/script/component/nowplaying-list.js";
import "./src/script/component/upcoming-list.js";
import "./src/script/component/nav-bar.js";
import main from "./src/script/view/main.js";


document.addEventListener("DOMContentLoaded", main);